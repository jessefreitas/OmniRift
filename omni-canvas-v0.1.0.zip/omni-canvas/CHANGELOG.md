# Changelog

Todas as mudanças notáveis deste projeto serão documentadas neste arquivo.

Formato baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.1.0/),
versionamento conforme [SemVer](https://semver.org/lang/pt-BR/).

## [Não publicado]

### Adicionado

- Scaffold inicial Tauri 2 + React + TypeScript
- Backend Rust com `portable-pty` 0.9 para PTYs cross-platform (Linux + Windows)
- `PtyManager` singleton com `DashMap` para concorrência sem contenção
- 5 comandos Tauri: `pty_spawn`, `pty_write`, `pty_resize`, `pty_kill`, `pty_list`
- Eventos `pty://output` e `pty://exit` para streaming bidirecional
- Frontend com `@xyflow/react` 12 para canvas infinito
- Nó terminal interativo com xterm.js, fit addon, web-links addon
- Hook `useTerminalSession` para ciclo de vida xterm ↔ PTY (com Strict Mode guard)
- Store Zustand com discriminated unions (`terminal | note | sketch | portal`)
- Sidebar com presets de agentes (Shell, Claude Code, Codex, OpenCode)
- Paleta dark mode Chatwoot Next Colors (bg, surface1/2, brand, danger)
- Build cross-platform: `.deb`, `.rpm`, `.AppImage`, `.msi`, `.exe (NSIS)`
- Scripts de bootstrap e diagnóstico do ambiente
- ADR-001 documentando a escolha de Tauri 2 sobre Electron

## [0.1.0] - 2026-05-14

Fase 1 do roadmap: **PTY + Canvas**.
