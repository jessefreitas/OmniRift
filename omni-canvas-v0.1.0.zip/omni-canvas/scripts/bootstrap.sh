#!/usr/bin/env bash
#
# scripts/bootstrap.sh
#
# Instala todas as dependências de sistema necessárias para desenvolver
# o Omni Canvas em uma máquina Linux limpa (Ubuntu/Debian).
#
# Uso:
#   chmod +x scripts/bootstrap.sh
#   ./scripts/bootstrap.sh

set -euo pipefail

C_RESET='\033[0m'
C_BRAND='\033[38;2;41;162;167m'
C_DIM='\033[2m'
C_OK='\033[1;32m'
C_WARN='\033[1;33m'

log() { echo -e "${C_BRAND}▸${C_RESET} $*"; }
ok()  { echo -e "${C_OK}✓${C_RESET} $*"; }
warn(){ echo -e "${C_WARN}!${C_RESET} $*"; }

log "Omni Canvas — bootstrap"
echo

# 1. Sistema (apt) ----------------------------------------------------------
if [[ -f /etc/debian_version ]]; then
  log "Detectado Debian/Ubuntu — instalando deps via apt"
  sudo apt-get update -qq
  sudo apt-get install -y \
    libwebkit2gtk-4.1-dev \
    build-essential \
    curl \
    wget \
    file \
    libxdo-dev \
    libssl-dev \
    libayatana-appindicator3-dev \
    librsvg2-dev \
    pkg-config
  ok "Dependências de sistema instaladas"
else
  warn "Distro não detectada — instale manualmente: webkit2gtk, gcc, libssl, libxdo"
fi

# 2. Rust -------------------------------------------------------------------
if ! command -v cargo &>/dev/null; then
  log "Instalando rustup..."
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
  # shellcheck source=/dev/null
  source "$HOME/.cargo/env"
  ok "Rust instalado: $(rustc --version)"
else
  ok "Rust já presente: $(rustc --version)"
fi

# 3. Node + pnpm ------------------------------------------------------------
if ! command -v node &>/dev/null; then
  log "Instalando Node 20 via nvm..."
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
  # shellcheck source=/dev/null
  source "$HOME/.nvm/nvm.sh"
  nvm install 20
  nvm use 20
  ok "Node instalado: $(node --version)"
else
  ok "Node já presente: $(node --version)"
fi

if ! command -v pnpm &>/dev/null; then
  log "Instalando pnpm..."
  npm install -g pnpm
  ok "pnpm instalado: $(pnpm --version)"
else
  ok "pnpm já presente: $(pnpm --version)"
fi

# 4. Tauri CLI (opcional, mas útil) -----------------------------------------
if ! command -v cargo-tauri &>/dev/null; then
  log "Instalando Tauri CLI global..."
  cargo install tauri-cli --version "^2.0" --locked
  ok "Tauri CLI instalado"
else
  ok "Tauri CLI já presente"
fi

# 5. Deps do projeto --------------------------------------------------------
log "Instalando dependências do projeto..."
pnpm install
ok "node_modules pronto"

log "Pré-compilando dependências Rust (uma vez só, leva ~5min)..."
(cd src-tauri && cargo build 2>&1 | tail -5)
ok "Rust deps compiladas"

echo
ok "${C_BRAND}Tudo pronto.${C_RESET} Rode: ${C_BRAND}pnpm tauri:dev${C_RESET}"
