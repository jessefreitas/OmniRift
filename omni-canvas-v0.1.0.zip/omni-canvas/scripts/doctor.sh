#!/usr/bin/env bash
#
# scripts/doctor.sh
#
# Diagnóstico do ambiente — checa todas as ferramentas necessárias.
# Não modifica nada. Use antes de abrir o projeto pela primeira vez.

set -uo pipefail

C_RESET='\033[0m'
C_OK='\033[1;32m'
C_ERR='\033[1;31m'
C_DIM='\033[2m'

ok()  { echo -e "${C_OK}✓${C_RESET} $1  ${C_DIM}$2${C_RESET}"; }
err() { echo -e "${C_ERR}✗${C_RESET} $1  ${C_DIM}faltando — $2${C_RESET}"; HAS_ERROR=1; }

HAS_ERROR=0

echo "Omni Canvas — diagnóstico de ambiente"
echo

# Node + pnpm + Rust + Cargo + Tauri CLI
command -v node    &>/dev/null && ok  "node"    "$(node --version)"    || err "node"    "instale via nvm"
command -v pnpm    &>/dev/null && ok  "pnpm"    "$(pnpm --version)"    || err "pnpm"    "npm i -g pnpm"
command -v rustc   &>/dev/null && ok  "rustc"   "$(rustc --version | awk '{print $2}')" || err "rustc" "rustup.rs"
command -v cargo   &>/dev/null && ok  "cargo"   "$(cargo --version | awk '{print $2}')" || err "cargo" "rustup.rs"

# Bibliotecas de sistema (Linux)
if [[ "$(uname)" == "Linux" ]]; then
  pkg-config --exists webkit2gtk-4.1 && ok "webkit2gtk-4.1" "presente" || err "webkit2gtk-4.1" "apt install libwebkit2gtk-4.1-dev"
  pkg-config --exists gtk+-3.0       && ok "gtk+-3.0"       "presente" || err "gtk+-3.0"       "apt install libgtk-3-dev"
fi

# Versões mínimas
NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0)
[[ "$NODE_MAJOR" -ge 20 ]] && ok "node ≥ 20" "$(node --version)" || err "node ≥ 20" "atualize Node"

RUST_VER=$(rustc --version 2>/dev/null | awk '{print $2}' || echo 0.0.0)
[[ "$(printf '%s\n' "1.77.0" "$RUST_VER" | sort -V | head -1)" == "1.77.0" ]] && ok "rustc ≥ 1.77" "$RUST_VER" || err "rustc ≥ 1.77" "rustup update"

echo
if [[ "$HAS_ERROR" -eq 0 ]]; then
  echo -e "${C_OK}Ambiente OK.${C_RESET} Rode: pnpm install && pnpm tauri:dev"
  exit 0
else
  echo -e "${C_ERR}Há pendências.${C_RESET} Veja ./scripts/bootstrap.sh para instalação automática."
  exit 1
fi
