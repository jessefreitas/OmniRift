// src/main.tsx
//
// Entry-point React. Monta no #root do index.html.
// StrictMode é INTENCIONAL — quero descobrir bugs de cleanup em dev.
// Por isso `useTerminalSession` tem o `spawnedRef` guard.

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles/globals.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
