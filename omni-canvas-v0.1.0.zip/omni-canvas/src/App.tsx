// src/App.tsx
//
// Shell raiz da aplicação. Layout: sidebar à esquerda + canvas à direita.
// Por enquanto, sem rotas — Fase 3 introduz múltiplos workspaces e router.

import { Canvas } from "@/components/Canvas";
import { Sidebar } from "@/components/Sidebar";

export default function App() {
  return (
    <div className="flex h-screen w-screen bg-bg">
      <Sidebar />
      <main className="flex-1 relative">
        <Canvas />
      </main>
    </div>
  );
}
