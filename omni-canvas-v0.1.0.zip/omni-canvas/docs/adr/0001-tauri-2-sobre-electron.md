# ADR-001 · Tauri 2 sobre Electron

**Status:** aceito · 2026-05-14
**Contexto:** OmniCanvas é uma aplicação desktop que precisa hospedar dezenas de PTYs simultâneos, um canvas espacial GPU-accelerated, e um browser embarcado (Fase 5).

## Decisão

Usar **Tauri 2** como framework de empacotamento desktop.

## Alternativas consideradas

| Opção | Bundle | RAM idle | DX | PTY | Veredito |
|---|---|---|---|---|---|
| Electron + Node | ~150MB | ~400MB | ⭐⭐⭐⭐⭐ | `node-pty` | Inviável para 30+ terminais |
| **Tauri 2 + Rust** | ~12MB | ~80MB | ⭐⭐⭐⭐ | `portable-pty` | **Escolhido** |
| Neutralino | ~2MB | ~50MB | ⭐⭐ | Ausente | Sem ecossistema PTY |
| Wails | ~10MB | ~70MB | ⭐⭐⭐ | Go pty libs | Go isola do ecossistema Rust |
| Flutter Desktop | ~25MB | ~120MB | ⭐⭐⭐⭐ | FFI manual | Dart afasta time OmniForge |

## Consequências

**Positivas:**
- Bundle final 12× menor que Electron equivalente
- Performance crítica do canvas e dos PTYs em Rust nativo
- Ecossistema Rust de PTY (portable-pty, wezterm-term) battle-tested
- IPC tipado entre Rust e TypeScript
- Multi-window real para o "Ombro" flutuante (Fase 7)

**Negativas:**
- Time precisa lidar com Rust no backend (curva inicial)
- Webview varia por plataforma (WebKitGTK no Linux, WebView2 no Windows). Bugs sutis de renderização requerem testes em ambas.
- Tauri 2 ainda evolui rápido — plugins podem ter breaking changes em minor versions

**Mitigações:**
- Toda lógica complexa de Rust fica isolada em `src-tauri/src/pty/` e `commands/` — frontend dev nunca precisa tocar
- CI cobre Linux + Windows desde o dia 1
- Plugins pinados a patch versions (`tauri-plugin-shell = "2.0"` não `"2"`)
