// src-tauri/src/lib.rs
//
// Bootstrap da aplicação Tauri.
// Aqui registramos:
//   - Plugins (shell, fs, dialog quando precisarmos)
//   - O estado global PtyManager (compartilhado entre comandos)
//   - Todos os #[tauri::command] expostos ao front-end
//
// Convenção do projeto OmniForge: tudo em um único `pub fn run()` para que
// `main.rs` (desktop) e futuros entry points mobile compartilhem o mesmo setup.

pub mod commands;
pub mod pty;

use commands::pty::{pty_kill, pty_list, pty_resize, pty_spawn, pty_write};
use pty::PtyManager;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    // Logger simples — em produção vamos para tracing-subscriber.
    let _ = env_logger::Builder::from_env(
        env_logger::Env::default().default_filter_or("info"),
    )
    .try_init();

    tauri::Builder::default()
        // PtyManager é singleton — uma instância para toda a app.
        .manage(PtyManager::new())
        .plugin(tauri_plugin_shell::init())
        .invoke_handler(tauri::generate_handler![
            pty_spawn,
            pty_write,
            pty_resize,
            pty_kill,
            pty_list,
        ])
        .run(tauri::generate_context!())
        .expect("erro fatal rodando Omni Canvas");
}
