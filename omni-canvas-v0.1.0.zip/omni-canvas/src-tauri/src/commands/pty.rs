// src-tauri/src/commands/pty.rs
//
// Comandos Tauri expostos ao front-end.
// Cada `#[tauri::command]` vira uma função TypeScript no front via @tauri-apps/api/core invoke().
//
// Convenção:
//   - Erros voltam como String (Tauri não serializa anyhow::Error direto).
//   - Argumentos são camelCase no JS, snake_case aqui — Tauri converte automático.

use crate::pty::{PtyManager, PtySpawnConfig, SessionId};
use tauri::{AppHandle, State};

/// Cria uma nova sessão PTY.
///
/// Front-end gera o `id` (nanoid) e passa junto. Isso evita race conditions
/// onde o front emite "input" antes de saber qual id foi atribuído.
#[tauri::command]
pub fn pty_spawn(
    id: SessionId,
    config: PtySpawnConfig,
    manager: State<'_, PtyManager>,
    app: AppHandle,
) -> Result<SessionId, String> {
    manager
        .spawn(id, config, app)
        .map_err(|e| format!("{e:#}"))
}

/// Envia bytes para o stdin do PTY (teclas do usuário).
#[tauri::command]
pub fn pty_write(
    session_id: SessionId,
    data: String,
    manager: State<'_, PtyManager>,
) -> Result<(), String> {
    manager
        .write(&session_id, data.as_bytes())
        .map_err(|e| format!("{e:#}"))
}

/// Redimensiona o PTY (cols x rows). Disparado quando o xterm.js no front se ajusta.
#[tauri::command]
pub fn pty_resize(
    session_id: SessionId,
    cols: u16,
    rows: u16,
    manager: State<'_, PtyManager>,
) -> Result<(), String> {
    manager
        .resize(&session_id, cols, rows)
        .map_err(|e| format!("{e:#}"))
}

/// Encerra a sessão (e o processo filho).
#[tauri::command]
pub fn pty_kill(
    session_id: SessionId,
    manager: State<'_, PtyManager>,
) -> Result<(), String> {
    manager.kill(&session_id).map_err(|e| format!("{e:#}"))
}

/// Lista todas as sessões ativas (debug).
#[tauri::command]
pub fn pty_list(manager: State<'_, PtyManager>) -> Vec<SessionId> {
    manager.list()
}
