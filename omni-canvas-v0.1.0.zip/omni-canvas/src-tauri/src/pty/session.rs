// src-tauri/src/pty/session.rs
//
// Uma sessão de PTY representa UM terminal no canvas.
// Cada nó do tipo "terminal" no front-end tem uma PtySession aqui no Rust.
//
// O ciclo de vida é:
//   1. spawn()  — cria o processo filho (bash, claude code, etc.)
//   2. tarefa async lê do master, emite "pty://{id}/output" via Tauri events
//   3. write_input() — front-end envia teclas
//   4. resize() — front-end avisa novo tamanho de cols/rows
//   5. kill() — encerra
//
// Detalhes finos:
//   - Em Linux usamos pty(7) padrão; em Windows o portable-pty usa ConPTY.
//   - O reader roda em thread separada (spawn_blocking) porque .read() é bloqueante.
//   - O writer fica num Mutex parking_lot (mais rápido que std).

use anyhow::{anyhow, Context, Result};
use parking_lot::Mutex;
use portable_pty::{native_pty_system, CommandBuilder, MasterPty, PtySize};
use serde::Serialize;
use std::io::{Read, Write};
use std::sync::Arc;
use tauri::{AppHandle, Emitter};

/// Identificador único de uma sessão PTY. Vem do front-end (nanoid).
pub type SessionId = String;

/// Configuração para iniciar uma sessão.
#[derive(Debug, Clone, serde::Deserialize)]
pub struct PtySpawnConfig {
    /// Comando a executar. Ex: "bash", "claude", "zsh", "cmd.exe".
    pub command: String,
    /// Argumentos do comando.
    #[serde(default)]
    pub args: Vec<String>,
    /// Diretório de trabalho. Se None, usa o cwd do processo pai.
    #[serde(default)]
    pub cwd: Option<String>,
    /// Variáveis de ambiente a adicionar/sobrescrever.
    #[serde(default)]
    pub env: Vec<(String, String)>,
    /// Colunas iniciais.
    #[serde(default = "default_cols")]
    pub cols: u16,
    /// Linhas iniciais.
    #[serde(default = "default_rows")]
    pub rows: u16,
}

fn default_cols() -> u16 {
    80
}
fn default_rows() -> u16 {
    24
}

/// Payload emitido para o front-end quando o PTY produz output.
#[derive(Debug, Clone, Serialize)]
pub struct PtyOutputEvent {
    pub session_id: SessionId,
    pub data: String,
}

/// Payload emitido quando o processo do PTY morre.
#[derive(Debug, Clone, Serialize)]
pub struct PtyExitEvent {
    pub session_id: SessionId,
    pub exit_code: Option<i32>,
}

/// Representa uma sessão de PTY ativa.
///
/// O `master` fica em Arc<Mutex<...>> porque tanto o reader thread quanto os
/// comandos de write/resize precisam de acesso. O leitor pega o reader UMA vez
/// no spawn e mantém para si — não precisa do mutex depois.
pub struct PtySession {
    pub id: SessionId,
    /// PTY master (lado do "host"). Usado para writes e resize.
    master: Arc<Mutex<Box<dyn MasterPty + Send>>>,
    /// Writer ao stdin do child. Mantido vivo para escrever caracteres.
    writer: Arc<Mutex<Box<dyn Write + Send>>>,
}

impl PtySession {
    /// Cria uma sessão e dispara a thread leitora.
    ///
    /// O AppHandle é necessário para emitir eventos para o front-end.
    pub fn spawn(id: SessionId, cfg: PtySpawnConfig, app: AppHandle) -> Result<Self> {
        let pty_system = native_pty_system();

        let pair = pty_system
            .openpty(PtySize {
                rows: cfg.rows,
                cols: cfg.cols,
                pixel_width: 0,
                pixel_height: 0,
            })
            .context("falha ao abrir PTY pair")?;

        // Monta o comando do child.
        let mut cmd = CommandBuilder::new(&cfg.command);
        for arg in &cfg.args {
            cmd.arg(arg);
        }
        if let Some(cwd) = &cfg.cwd {
            cmd.cwd(cwd);
        }
        for (k, v) in &cfg.env {
            cmd.env(k, v);
        }

        // Spawn do processo filho conectado ao slave.
        let mut child = pair
            .slave
            .spawn_command(cmd)
            .context("falha ao spawnar processo no PTY")?;

        // O slave já foi consumido pelo spawn; podemos descartar.
        drop(pair.slave);

        let master = Arc::new(Mutex::new(pair.master));

        // Pega o reader do master ANTES de mover para o Arc — só pode ser feito 1x.
        let reader = master
            .lock()
            .try_clone_reader()
            .context("falha ao clonar reader do master")?;

        // Pega o writer também — também só 1x.
        let writer: Box<dyn Write + Send> = master
            .lock()
            .take_writer()
            .context("falha ao tomar writer do master")?;
        let writer = Arc::new(Mutex::new(writer));

        // Thread leitora — emite output_event para o front-end.
        let id_for_reader = id.clone();
        let app_for_reader = app.clone();
        std::thread::spawn(move || {
            read_loop(id_for_reader, reader, app_for_reader);
        });

        // Thread que aguarda o child morrer e emite exit_event.
        let id_for_waiter = id.clone();
        let app_for_waiter = app.clone();
        std::thread::spawn(move || match child.wait() {
            Ok(status) => {
                let code = status.exit_code() as i32;
                let _ = app_for_waiter.emit(
                    "pty://exit",
                    PtyExitEvent {
                        session_id: id_for_waiter,
                        exit_code: Some(code),
                    },
                );
            }
            Err(e) => {
                log::error!("erro aguardando child do PTY: {e}");
                let _ = app_for_waiter.emit(
                    "pty://exit",
                    PtyExitEvent {
                        session_id: id_for_waiter,
                        exit_code: None,
                    },
                );
            }
        });

        Ok(Self {
            id,
            master,
            writer,
        })
    }

    /// Escreve dados no stdin do child (teclas do usuário).
    pub fn write(&self, data: &[u8]) -> Result<()> {
        let mut w = self.writer.lock();
        w.write_all(data).context("falha ao escrever no PTY")?;
        w.flush().context("falha ao flush do PTY")?;
        Ok(())
    }

    /// Redimensiona o PTY (avisa o child via SIGWINCH no Linux).
    pub fn resize(&self, cols: u16, rows: u16) -> Result<()> {
        self.master
            .lock()
            .resize(PtySize {
                rows,
                cols,
                pixel_width: 0,
                pixel_height: 0,
            })
            .map_err(|e| anyhow!("falha ao redimensionar PTY: {e}"))?;
        Ok(())
    }
}

/// Loop blocking que lê do PTY e emite eventos para o front-end.
///
/// Roda numa thread dedicada. Quando o child morre, o read retorna 0 bytes
/// e a thread sai naturalmente.
fn read_loop(id: SessionId, mut reader: Box<dyn Read + Send>, app: AppHandle) {
    let mut buf = [0u8; 4096];
    loop {
        match reader.read(&mut buf) {
            Ok(0) => {
                // EOF — o child fechou o pty.
                log::info!("PTY {id} EOF, encerrando reader");
                break;
            }
            Ok(n) => {
                // O child pode emitir bytes não-UTF-8 (sequências ANSI binárias
                // mal-formadas, etc). Usamos from_utf8_lossy para nunca quebrar.
                let chunk = String::from_utf8_lossy(&buf[..n]).to_string();
                if let Err(e) = app.emit(
                    "pty://output",
                    PtyOutputEvent {
                        session_id: id.clone(),
                        data: chunk,
                    },
                ) {
                    log::error!("falha ao emitir output do PTY {id}: {e}");
                    break;
                }
            }
            Err(e) => {
                log::warn!("erro lendo do PTY {id}: {e}");
                break;
            }
        }
    }
}
