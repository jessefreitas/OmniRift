// src-tauri/src/pty/manager.rs
//
// O PtyManager mantém o mapa { session_id -> PtySession }.
// É um singleton armazenado no Tauri state.
//
// DashMap nos dá leitura/escrita concorrente sem precisar de RwLock global —
// cada bucket tem seu próprio lock. Importante quando temos 30+ terminais
// recebendo dados simultaneamente.

use crate::pty::session::{PtySession, PtySpawnConfig, SessionId};
use anyhow::{anyhow, Result};
use dashmap::DashMap;
use std::sync::Arc;
use tauri::AppHandle;

#[derive(Default)]
pub struct PtyManager {
    sessions: Arc<DashMap<SessionId, Arc<PtySession>>>,
}

impl PtyManager {
    pub fn new() -> Self {
        Self::default()
    }

    /// Cria uma nova sessão. Retorna o id (já vem do front-end).
    pub fn spawn(
        &self,
        id: SessionId,
        cfg: PtySpawnConfig,
        app: AppHandle,
    ) -> Result<SessionId> {
        if self.sessions.contains_key(&id) {
            return Err(anyhow!("sessão {id} já existe"));
        }
        let session = PtySession::spawn(id.clone(), cfg, app)?;
        self.sessions.insert(id.clone(), Arc::new(session));
        Ok(id)
    }

    pub fn write(&self, id: &str, data: &[u8]) -> Result<()> {
        let session = self
            .sessions
            .get(id)
            .ok_or_else(|| anyhow!("sessão {id} não encontrada"))?;
        session.write(data)
    }

    pub fn resize(&self, id: &str, cols: u16, rows: u16) -> Result<()> {
        let session = self
            .sessions
            .get(id)
            .ok_or_else(|| anyhow!("sessão {id} não encontrada"))?;
        session.resize(cols, rows)
    }

    pub fn kill(&self, id: &str) -> Result<()> {
        // Drop da Arc<PtySession> derruba master/writer, o que fecha o PTY
        // e dispara EOF na thread leitora. O child recebe SIGHUP no Linux.
        self.sessions
            .remove(id)
            .ok_or_else(|| anyhow!("sessão {id} não encontrada"))?;
        Ok(())
    }

    pub fn list(&self) -> Vec<SessionId> {
        self.sessions.iter().map(|e| e.key().clone()).collect()
    }
}
