// src-tauri/src/main.rs
//
// Entry point do binário desktop. Em produção a janela não tem console.
// O grosso da lógica fica em lib.rs (omni_canvas_lib::run) para que
// futuros targets mobile (Android/iOS) possam reaproveitar.

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    omni_canvas_lib::run();
}
