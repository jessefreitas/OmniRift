# Contribuindo com o Omni Canvas

Bem-vindo. Este projeto segue o fluxo de desenvolvimento padrão da **OmniForge** —
disciplinado, rastreável, sem regressão.

## Princípios

1. **Toda mudança nasce de um card Kanban** em `chat.omniforge.com.br`. Sem card, sem código.
2. **Toda branch sai de uma worktree** isolada. Nunca trabalhe direto na `main`.
3. **Toda decisão arquitetural vira um ADR** em `docs/adr/NNNN-titulo.md`.
4. **Todo bug fix referencia o card** no commit (`fix(pty): SIGWINCH no Win [card-OMC-42]`).
5. **Código completo e consolidado** — nunca trechos parciais. Se mudou, mande o arquivo inteiro.

## Setup local

```bash
git clone <repo> && cd omni-canvas
./scripts/doctor.sh        # valida ambiente
./scripts/bootstrap.sh     # instala o que faltar
pnpm tauri:dev             # roda em modo dev
```

## Fluxo por fase

O roadmap tem 7 fases (ver `README.md`). Cada fase é um épico no Kanban com N cards.

### 1. Pegue um card

No board `chat.omniforge.com.br/funnels/omni-canvas`, mova o card de **Backlog → In Progress**.
Anote o ID (ex: `OMC-23`).

### 2. Crie a worktree

```bash
# A partir da raiz do repo
git worktree add ../omni-canvas-OMC-23 -b feature/OMC-23-titulo-curto

cd ../omni-canvas-OMC-23
```

### 3. Trabalhe + Claude Code

```bash
# Dentro da worktree
claude  # ou seu agente preferido
```

Cole o contexto do card no início da sessão. Peça por mudanças incrementais com testes.

### 4. Quality gates antes do PR

```bash
pnpm typecheck
pnpm lint
cd src-tauri && cargo clippy -- -D warnings && cargo fmt --check
```

Use a skill `non-regression-guard` para garantir que nada quebrou.

### 5. Commit conventions

Use Conventional Commits + referência ao card:

```
feat(canvas): adiciona NodeResizer aos terminais [OMC-23]
fix(pty): SIGWINCH não chegava em Windows ConPTY [OMC-42]
docs(adr): ADR-007 explica decisão de SQLite [OMC-51]
refactor(store): extrai canvas-store para hook próprio [OMC-29]
chore: bump portable-pty 0.9.0 → 0.9.1 [OMC-60]
```

Tipos aceitos: `feat`, `fix`, `docs`, `refactor`, `chore`, `test`, `perf`, `style`.

### 6. PR e merge

- PR contra `main`, com link do card no corpo.
- Pelo menos 1 review (ou aprovação do agente Ratchet em modo audit).
- CI verde (GitHub Actions: lint, typecheck, cargo clippy, build Linux + Windows).
- Squash merge — branch some, history fica limpo.

### 7. Pós-merge

- Mova o card para **Done** no Kanban.
- Atualize o `CHANGELOG.md` na seção `[Não publicado]`.
- Se aprendeu algo novo, salve no OmniMemory via MCP claude-memory.
- **Após qualquer correção feita, finalize com: "Atualize seu CLAUDE.md para não cometer esse erro novamente."**

## Estrutura de uma ADR

```markdown
# ADR-NNN · Título curto

**Status:** proposto | aceito | obsoleto · YYYY-MM-DD
**Contexto:** [problema concreto que motivou]

## Decisão
[o que decidimos, em uma frase]

## Alternativas consideradas
| Opção | Prós | Contras | Veredito |
| --- | --- | --- | --- |

## Consequências
- Positivas:
- Negativas:
- Mitigações:
```

## Reportando bugs

Abra um card no Kanban com:

- **Resumo:** uma frase
- **Reprodução:** passos minimais
- **Esperado vs Atual**
- **Ambiente:** OS, versão do app, versão do agente (Claude Code, Codex, etc.)
- **Logs:** stderr do Rust (`RUST_LOG=debug pnpm tauri:dev` mostra tudo)

## Código de conduta

Honestidade técnica acima de cortesia performática. Discordâncias bem-vindas;
ataques pessoais não. Crítica do código, não do autor.

— OmniForge Automações e Inteligência Artificial
