import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "node:path";

// Tauri exige porta fixa para HMR (configurada em tauri.conf.json: devUrl).
// Em produção o app não usa HTTP — carrega via custom protocol asset://.

const host = process.env.TAURI_DEV_HOST;

export default defineConfig({
  plugins: [react()],
  clearScreen: false,
  resolve: {
    alias: {
      "@": resolve(__dirname, "./src"),
    },
  },
  server: {
    port: 1420,
    strictPort: true,
    host: host || false,
    hmr: host
      ? {
          protocol: "ws",
          host,
          port: 1421,
        }
      : undefined,
    watch: {
      // Não fica olhando o backend Rust — o Tauri CLI cuida disso.
      ignored: ["**/src-tauri/**"],
    },
  },
  // Vite faz tree-shaking agressivo. Esses warnings sobre source-map são ruído.
  build: {
    target: process.env.TAURI_ENV_PLATFORM === "windows" ? "chrome105" : "safari13",
    minify: !process.env.TAURI_ENV_DEBUG ? "esbuild" : false,
    sourcemap: !!process.env.TAURI_ENV_DEBUG,
  },
});
