# Omni Canvas

> Canvas infinito para orquestrar agentes de IA — Linux + Windows nativo
> **OmniForge** · v0.1.0 · Fase 1 (PTY + canvas)

Um clone open-source do [Maestri](https://www.themaestri.app) para Linux e Windows, com integração nativa ao ecossistema OmniForge (n8n, OmniMemory, OmniChat Kanban).

## Por que existe

O Maestri é macOS-only e fechado. Times que rodam Linux ou Windows ficaram de fora. O OmniCanvas resolve isso e adiciona o que falta no original: bridge nativa para infra de produção (n8n, OmniMemory, Kanban automation).

## Stack

| Camada | Tecnologia |
|---|---|
| **Frontend** | React 18 · TypeScript · Tailwind · React Flow · xterm.js · Zustand |
| **Core** | Rust · Tauri 2.11 · portable-pty · tokio · dashmap |
| **Build** | Vite 6 · pnpm · cargo |

Bundle final: ~12MB no Linux, ~18MB no Windows. RAM em idle: < 80MB.

## Como rodar

### Pré-requisitos

**Linux (Debian/Ubuntu):**
```bash
sudo apt update
sudo apt install -y libwebkit2gtk-4.1-dev build-essential curl wget file \
  libxdo-dev libssl-dev libayatana-appindicator3-dev librsvg2-dev
```

**Windows:** Microsoft C++ Build Tools + WebView2 (já vem com Windows 11).

**Comum:**
- Node.js ≥ 20 e pnpm ≥ 9
- Rust ≥ 1.77 (`rustup install stable`)

### Setup

```bash
git clone <repo>
cd omni-canvas
pnpm install
pnpm tauri:dev
```

Na primeira execução o Cargo baixa ~600MB de dependências Rust. Próximas builds: instantâneas.

### Build de produção

```bash
pnpm tauri:build
```

Saída em `src-tauri/target/release/bundle/`:
- **Linux:** `.deb`, `.rpm`, `.AppImage`
- **Windows:** `.msi`, `.exe` (NSIS)

## Arquitetura

```
┌────────────────────────────────────────────────────────────────┐
│                    Frontend (WebView)                          │
│  React + xterm.js + React Flow + Zustand                       │
└────────────────────┬───────────────────────────────────────────┘
                     │  IPC (Tauri commands + events)
                     │  • invoke('pty_spawn' | 'pty_write' | ...)
                     │  • listen('pty://output' | 'pty://exit')
┌────────────────────▼───────────────────────────────────────────┐
│                    Core Rust (binário)                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │  PtyManager  │──│  PtySession  │──│  portable-pty + OS   │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

### Fluxo de uma tecla

1. Usuário digita no xterm.js
2. `term.onData` → `ptyWrite(sessionId, data)` no `pty-client.ts`
3. `invoke('pty_write', ...)` viaja por IPC até o Rust
4. `PtyManager::write` localiza a `PtySession` no DashMap
5. `PtySession::write` escreve no `master` PTY
6. Kernel encaminha ao processo filho (bash, claude, etc.)
7. Processo filho responde → kernel → reader thread em Rust
8. Rust emite evento `pty://output` com o session_id
9. `listenPtyOutput` filtra pelo session_id e chama `term.write(data)`
10. xterm.js renderiza no canvas

Latência típica em loopback: < 2ms.

## Estrutura de pastas

```
omni-canvas/
├── src/                          # Frontend React
│   ├── components/
│   │   ├── Canvas.tsx            # React Flow integrado
│   │   ├── Sidebar.tsx           # Presets de agentes
│   │   └── nodes/
│   │       └── TerminalNode.tsx  # Nó terminal interativo
│   ├── hooks/
│   │   └── useTerminalSession.ts # Conecta xterm ↔ PTY do Rust
│   ├── lib/
│   │   ├── pty-client.ts         # Wrapper invoke() tipado
│   │   └── cn.ts                 # Helper Tailwind
│   ├── store/
│   │   └── canvas-store.ts       # Zustand: nós + edges
│   ├── styles/
│   │   └── globals.css           # Tokens + React Flow overrides
│   ├── types/
│   │   ├── canvas.ts             # Tipos de nó
│   │   └── pty.ts                # Tipos espelhados do Rust
│   ├── App.tsx
│   └── main.tsx
└── src-tauri/                    # Backend Rust
    ├── src/
    │   ├── pty/
    │   │   ├── manager.rs        # Map { session_id → session }
    │   │   ├── session.rs        # Spawn, read loop, write, resize
    │   │   └── mod.rs
    │   ├── commands/
    │   │   └── pty.rs            # #[tauri::command] expostos
    │   ├── lib.rs                # Builder + plugins + handlers
    │   └── main.rs               # Entry point
    ├── capabilities/
    │   └── default.json          # ACL do Tauri 2
    ├── Cargo.toml
    └── tauri.conf.json
```

## Roadmap

| Fase | Status | Escopo |
|---|---|---|
| **0 — Setup** | ✅ feito | Scaffold, Tauri 2, CI |
| **1 — PTY + Canvas** | ✅ atual | Multi-terminais, drag, resize |
| **2 — Conexões PTY** | □ próximo | Output de A → input de B via edge |
| **3 — Roles + persistência** | □ | Workspaces salvos em SQLite |
| **4 — Sketches + Notes** | □ | tldraw + notas escritas por agentes |
| **5 — Portals** | □ | Browser embarcado via CDP |
| **6 — Floors + Routines** | □ | Worktrees + scheduler |
| **7 — Ombro + Bridges** | □ | Ollama local + OmniMemory + n8n |

## Decisões arquiteturais

Veja `docs/adr/` para o histórico completo.

- **ADR-001:** Tauri 2 sobre Electron — bundle 12× menor, RAM 5× menor
- **ADR-002:** portable-pty sobre alacritty-core — cobertura Windows ConPTY
- **ADR-003:** React Flow sobre custom canvas — produtividade > otimização prematura
- **ADR-004:** Zustand sobre Redux — store mínimo, sem boilerplate
- **ADR-005:** xterm.js sobre WezTerm-term Rust — ecossistema, addons prontos

## Licença

MIT. Veja `LICENSE`.

---

**Atualize seu CLAUDE.md para não cometer esse erro novamente.** Convenção OmniForge — toda alteração no projeto deve ser registrada como ADR e commit deve referenciar o card Kanban (`chat.omniforge.com.br`).
